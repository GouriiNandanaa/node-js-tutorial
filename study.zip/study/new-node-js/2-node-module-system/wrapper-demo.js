const wrapperExplorer = require('./wrapper-explorer');
console.log(`Filename from the demo ${__filename}`)
console.log(`Direname from the demo ${__dirname}`)


wrapperExplorer.greet("Gouri")