console.log('hello world- this is node js')

const array = [1,2,4]
console.log(array, "array")


setTimeout(()=>{
    console.log("Hi this is a message that is delayed")
},2000)

console.log("this is the last line of the code")