const num1 = 12;
const num2 = 13;

const sumCalcu = ()=> num1 + num2;
console.log(sumCalcu());

module.exports = sumCalcu;