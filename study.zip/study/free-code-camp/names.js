const john = "John"
const peter = "Peter"


module.exports = {john, peter}