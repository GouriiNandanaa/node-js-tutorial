const sayHi = (name) => {console.log(`Hello ${name}`)};
sayHi('jithin')
console.log(typeof(sayHi))

module.exports = sayHi