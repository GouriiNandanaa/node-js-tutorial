const names = require('./names')
const sayHi = require('./utils')
console.log(typeof(sayHi))
console.log(names.john)

sayHi(names.peter)

const sumCalcu = require('./7-mind-games')